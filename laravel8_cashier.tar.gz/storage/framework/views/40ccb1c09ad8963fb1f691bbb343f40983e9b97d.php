        </div>
    </body>    
</html><?php /**PATH /var/www/html/study/laravel8/resources/views/footer.blade.php ENDPATH**/ ?>