<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="product-table" class="table table-bordered">
    <thead>
        <tr class="table-active">
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($key + 1); ?></th>
            <td><?php echo e($product->name); ?></td>
            <td>Rs <?php echo e($product->price); ?></td>
            <td><a href="/product/show/<?php echo e($product->id); ?>" class="btn btn-sm btn-primary">Buy</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php if(session('message')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(session('message')); ?></div>
<?php endif; ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#product-table').DataTable();
    });
</script>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/study/laravel8/resources/views/products/list.blade.php ENDPATH**/ ?>